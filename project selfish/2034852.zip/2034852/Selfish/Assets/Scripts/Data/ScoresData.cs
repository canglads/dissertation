﻿using System;

[Serializable]
public class ScoresData
{
	//lower case for consistency with json
	public Score[] scores { get; set; }

}
