﻿using UnityEngine;
using System.Collections;

public class OrganismMovement : MonoBehaviour {
	
	public float speed = 4f;

}
